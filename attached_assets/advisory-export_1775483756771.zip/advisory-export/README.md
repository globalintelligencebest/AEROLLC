# AERO Advisory — Standalone Website

Self-contained React + Express scaffold for **aerocooperation.com** (the AERO Advisory website). This is **entirely separate** from the PLANE tax application at **planetaxapp.com**.

## Domain Separation

| Site | Domain | Purpose |
|------|--------|---------|
| AERO Advisory (this repo) | aerocooperation.com | AI governance advisory, company info |
| PLANE App | planetaxapp.com | Tax app (external link only) |

- All "Try the App" / "Sign Up" CTAs in this site link externally to `https://planetaxapp.com`
- This site has **zero** tax app code: no database models, no auth, no Stripe, no AI services
- The Express backend only serves `/api/health` and static assets in production

## Setup

```bash
npm install
npm run dev        # development: Express + Vite middleware, serves on port 5000
npm run build      # production build
npm start          # serve production build (Express + static dist)
```

In **development**, `npm run dev` starts Express which in turn uses Vite's middleware mode — so `http://localhost:5000/` immediately serves the Governance page (React SPA). No separate Vite process is needed.

In **production**, `npm run build` outputs to `dist/public/` and `npm start` serves it statically.

## Structure

```
advisory-export/
├── index.html                   # Entry HTML (OG tags for aerocooperation.com)
├── client/
│   ├── public/
│   │   ├── aero_logo_blue.png
│   │   └── aero_logo_white.png
│   └── src/
│       ├── App.tsx              # Wouter router — / → Governance
│       ├── main.tsx
│       ├── index.css            # AERO navy theme
│       ├── components/
│       │   ├── GovernanceFooter.tsx
│       │   └── ui/              # Shadcn UI components
│       ├── hooks/use-toast.ts
│       ├── lib/
│       │   ├── utils.ts
│       │   └── queryClient.ts
│       └── pages/
│           ├── Governance.tsx          # → / (AI governance landing)
│           ├── Advisory.tsx            # → /advisory
│           ├── FinancingPage.tsx       # → /financing
│           ├── GovernmentPage.tsx      # → /government
│           ├── Hiring.tsx              # → /hiring
│           ├── JobDetail.tsx           # → /hiring/:id
│           ├── LeadershipPage.tsx      # → /leadership
│           ├── Press.tsx               # → /press
│           ├── SecurityAiGovernance.tsx # → /security-ai-governance
│           └── AdminGovernance.tsx     # → /admin/governance
├── server/
│   └── index.ts                 # Express + Vite middleware (dev) / static (prod)
├── package.json
├── vite.config.ts
├── tailwind.config.ts
├── tsconfig.json
└── postcss.config.js
```

## Deployment on Replit

1. Open this project in Replit
2. Run `npm install` in the terminal (inside `advisory-export/`)
3. Set the workflow start command to `npm run dev`
4. The app runs on port 5000 — navigate to `/` to see the Governance landing page

## AERO Color Palette

Primary navy: `hsl(220 64% 33%)` — #1E3A8A  
Accent cyan: `hsl(195 80% 50%)`
